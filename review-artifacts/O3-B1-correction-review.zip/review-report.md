# O3-B1 continuation review — R1 blocks integration

The continuation implements the previously absent FRESH and cognition paths, but this version is not accepted. An independent hosted regression demonstrates that the approved runtime mapping's supported output limit is ignored during actual cognition dispatch and settlement.

## R1 — high: mapping bounds do not constrain the operation

`src/Imperium/Runtime/Onboarding/Augur/BaseProjection.php` validates the shape and nonnegative values of `supported_limits` through `SharedExposure::meters(..., false)`. Its selected-row comparison checks dispatch ID, configuration digest and revision limitation, but does not check compatibility between those supported limits and the requested workload/configuration. `FreshProducer` accepts that proposal and the matching map completion. `AugurAdapter::context` then constructs a reservation with the fixed global maximum of 4,096 output tokens; it does not compare it with the selected mapping's supported output limit. Runtime consequently accepts the operation and response under its global/token-evidence checks.

The reviewer fixture changes the map before real signing/admission so every mapped candidate has `supported_limits.output_tokens = 0`. It consistently updates candidate mapping references, the map approval terms and the map-base step. Production code, all original tests, the factual verifiers and all other mock-provider behavior remain unchanged. The public Runtime entry executes real base selection, map completion, FRESH publication and W1 with exact mock HTTP.

Observed hosted proof:

| Measure | Result |
| --- | ---: |
| Approved mapping output support | 0 tokens |
| Cognition POST calls | 1 |
| Reserved output tokens | 4,096 |
| Reported generated tokens | 1,415 |
| Assessment outcome | SUCCEEDED |
| Refusal | None |

Expected: refuse before cognition POST. A syntactically valid map must not silently inherit the larger global ceiling. A correct signature authenticates the restrictive mapping; it does not make the contradiction disappear.

[Reviewer CI](https://github.com/gatomontes/imperium-symfony/actions/runs/34688376106) completed with **1 test, 2 assertions, 1 failure**, PHP 8.4.25 / PHPUnit 13.3.0, in 04:03.927. The actual checkout `29403dadf5931f5cb505f1300c53931bfde7241a` has tree `822aada8216900ff7b9ba68814b0146162f350ee`, verified against the probe tree. The full public log is included. The only probe delta is two new test files plus a focused workflow; no candidate production source changed.

## Required correction

Enforce supported-limit compatibility from the exact selected runtime map through base eligibility, founding, prepared operation and custody revalidation/dispatch as appropriate. Preserve the approved fixed configuration and global ceilings. Unsupported configurations must refuse; do not lower or rewrite approved settings just to make a candidate fit, raise the mapping's allowance, or bypass the verifier.

Cover every supported meter, with boundary-equal success and strictly lower/zero cases. Preserve the submitted positive FRESH/W1–W3 tests, original regressions, and the unchanged reviewer test. When a final mapping limit is stricter than the requested operation, no POST or successful settlement may cross that limit. Preserve O1's eligibility and deterministic selection semantics.

## Source and package verification

- Preparation: `02ce09621c63822eaff9ffd23151d5d3aed593a4`, tree `2fc0e9075ce199312797533d237652fa15b82865`.
- Continuation entry: `8ebee96cbdcd43e5e89e8b1d222d83cd285b2e2d`.
- Tested local commit: `22072aa1936d3f4fc0d97cbdd484dc322a4b421c`.
- Submitted final: `18ff81299c42dc9fb60d49b419be8b7cfc38d1e3`, tree `7d08b1cff544ef8c1054afdcdaf1ddb7ccff7e20`.
- Published review head: `f80b8e095bfb3cffff070c1b1c24257dc53492f4`, exactly the submitted final tree.
- All 246 payload-manifest entries, the inner ZIP checksum, 49 canonical files, and 1,846 captured PHP byte streams verified. Every captured PHP file matches both tested and final Git bytes. Both patches independently reconstruct the final tree.
- Diff checks and an independent run of all 86 static specification checks pass. Their scope is abstract specification validation, not PHP runtime proof.
- The packet's 860 tests / 8,145 assertions are supplied local selection results. The separate hosted reviewer failure is independently obtained evidence.

## GitHub disposition and CI status

[PR #794](https://github.com/gatomontes/imperium-symfony/pull/794) remains draft, blocked by R1 and unmerged. [PR #795](https://github.com/gatomontes/imperium-symfony/pull/795) is a diagnostic-only draft and must not be merged. Main was unchanged when the review branch was created.

The unchanged complete candidate suite was started in [run 34688187703](https://github.com/gatomontes/imperium-symfony/actions/runs/34688187703) and was still running when this report was saved. Its passing credential regression is not a complete-suite result. No complete CI pass is claimed. An eventual pass cannot supersede the independently reproduced R1 failure. Corrected source needs a fresh complete run after review.

## Local continuation

Use `correction-prompt.txt` in the existing local implementation worktree. `reviewer-tests.patch` adds only the two reviewer PHP files and can be applied after `git apply --check`. The full `reviewer-probe.patch` also changes the diagnostic workflow: it is evidence only and must not be applied to the implementation branch. Preserve the complete-suite workflow and its 30-minute allowance.

Return a complete corrected O3-B1 packet. No new planning campaign, O4/O5 work, live activation, push or merge is included in the local correction run.
