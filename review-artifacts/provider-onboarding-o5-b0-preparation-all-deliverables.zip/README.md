# O5 CLI preparation packet

Prepared the operator-facing command specification, illustrative terminal sessions and future implementation checklist. O4 performance work is deferred; O5 implementation remains blocked on accepted O4 integration.

Read:

1. `docs/provider-onboarding-o5-cli-preparation.md` — commands, statuses, effects and existing-owner gaps.
2. `docs/provider-onboarding-o5-cli-examples.md` — illustrative sessions, not executable fixtures or runtime proof.
3. `docs/handoffs/provider-onboarding-o5-cli-checklist.md` — future work and entry gate; not a prompt to run now.
4. `docs/provider-onboarding-implementation-roadmap.md` — current deferral/preparation notice with historical content preserved.

Documentation only. No PHP changes, tests, profiling, CI, provider calls, merge or live activation. Published on a separate preparation branch to preserve the packet without starting CI. Main and PR #798 are not advanced by this preparation.

The main useful gap identified is the public status projection: the existing recovery status supplies RETAINED/pending_claims, not the complete seven-dimension operator view. Other explicit checks cover preview purity, lock-file/missing-root behavior, exact input ID domains, and evidence-only resume.
