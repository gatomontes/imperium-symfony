$ErrorActionPreference = "Stop"
git fetch origin refs/heads/codex/provider-onboarding-o5-b0-preparation
if ($LASTEXITCODE -ne 0) { throw "Fetch failed" }
$tempZip = Join-Path $env:TEMP ("o5-preparation-" + [guid]::NewGuid() + ".zip")
git archive --format=zip --output="$tempZip" FETCH_HEAD:review-artifacts provider-onboarding-o5-b0-preparation-all-deliverables.zip
if ($LASTEXITCODE -ne 0) { throw "Archive failed" }
Expand-Archive -LiteralPath $tempZip -DestinationPath "$env:USERPROFILE\Downloads" -Force
Remove-Item -LiteralPath $tempZip
