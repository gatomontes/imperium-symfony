# O4-B0 CI completion — INCOMPLETE checkpoint

Continuation from `8fb6323e615432a949ce4bf599389d501650b2df`, tree `892afbd68ad62bdc2eba9bc14927dff2e72827d2`. Production source is unchanged. This is a diagnostic checkpoint, not a completion packet, implementation delivery, integration approval, or fresh full-suite pass.

## Work performed

Verified all 18 payload hashes in the supplied review archive. Inspected the exact worktree, accepted R1/JSON changes and current O4 designs. Existing untracked work was preserved. Three diagnostic mechanisms and one transition-scope prototype ran serially against isolated copies of the unchanged producer test; no provider calls or real credentials were used.

| Fresh diagnostic | External seconds | Result |
| --- | ---: | --- |
| Caller stacks | 168.544 | 1 test / 55 assertions, exit 0 |
| Existing pure encoding reuse counters | 140.123 | 1 test / 55 assertions, exit 0 |
| Wider pure reuse during locked transition, prototype only | 131.124 | 1 test / 55 assertions, exit 0 |
| Journal-operation attribution | 148.329 | 1 test / 55 assertions, exit 0 |

Fresh production verification also passed the unchanged JSON/R2 regression selection (9 tests, 2,095 assertions) and all 86 static specification checks; exact commands and logs are included.

The four producer diagnostic runs are repeated selections of the same test, not four disjoint tests or a full acceptance gate. Instrumentation differs, so elapsed differences do not prove a production speed improvement. The owning-boundary run includes matching before/after source manifests. Full commands and logs are included.

## Findings

The first diagnostic independently reproduced 113 journal reads, 722 StateValidation runs and 152,095 act verifications. One repeated recursive source-check stack accounted for 142,362 act verifications (93.60%). Migration predecessor validation accounted for 360 StateValidation calls. The caller evidence does not authorize omitting either kind of check: predecessors represent different states, and source verification checks current trust, time, revocation, original bytes and signatures.

Existing bounded reuse recorded 9,454,297 canonical calls, 2,697,669 indexed candidates, 1,543,616 exact-value matches and 1,416,249 stored encoding hits. It is active, rather than globally missing. An indexed candidate is not necessarily an equal record; references can share schema/id with records.

A cache-free reference encoder matched 23 diagnostic value/error cases and averaged 0.442 versus 0.510 seconds for 200,000 calls (13.34% faster for that isolated operation). This is not enough evidence of a full-suite remedy. Its proof is diagnostic and not a comprehensive regression suite.

The transition-scope prototype calls the existing bounded StrictJson::within around the atomic callback. It retains all validation calls and storage limits. It extends pure-reuse lifetime and introduces an onboarding dependency into shared persistence, so it remains outside production. The observed 131-versus-140-second runs have different instrumentation; no controlled improvement is claimed.

The two leading custody-checkpoint caller groups contain 20 journal boundaries, 58,625 act verifications and 47.888 seconds of measured callback time. All 152,095 act verifications were attributed to journal callbacks; none occurred outside the measured owning boundary.

`owner-summary.json` attributes measured time and act counts to the actual journal-operation callers. `owner-boundaries.json` retains every boundary. The owning scope is recorded when entering the existing atomic callback, after lock acquisition; counters do not time lock waits or external provider activity.

## Unresolved completion gate

The supplied review records that the unchanged full local suite exited 124 after 1,800.722 seconds, and the reviewed hosted gate was canceled at its unchanged allowance. Those are inherited logs, clearly separated from fresh diagnostic logs. This continuation did not rerun that same unchanged full suite, modify its command/workflow/timeout, or obtain a full passing summary.

No sufficiently effective, regression-verified correction was established in this continuation. That is the unresolved work, not proof that completion is impossible. No production experiment was retained. This checkpoint must not be represented as O4 completion.

## Precise continuation

Start from the unchanged commit above. Profile CustodyCoordinator::checkpoint first: its two leading caller groups account for 47.888 seconds in this producer. Attribute its pure-computation cost within that operation (retained-byte parsing, canonical encoding and key construction versus signature and fresh-authority work). Develop and measure a correction at that boundary, with differential byte/error and adversarial currentness proof. Preserve migration predecessor validation and all recursive authority boundaries; the counts alone do not justify a semantic or signature cache. The observed small reference-encoding and scope experiments are insufficient acceptance evidence.

Once a justified correction exists, run the unchanged `vendor/bin/phpunit tests` within 1,800 seconds on frozen source, retain a complete successful summary and before/after PHP manifests, then prepare the requested completion-v2 packet for independent source review and fresh hosted CI. The complete slow-test diagnosis and successful full gate still remain outstanding.

All existing tracked files, tests, fixtures, service configuration, dependency locks, operational flags and retry allowlist remain unchanged. No merge, O5 transition or activation was performed. The packet contains the exact source snapshot, Git-blob comparisons, diagnostic scripts and variants, inherited gate evidence, inner review ZIP/hash and payload manifest.
