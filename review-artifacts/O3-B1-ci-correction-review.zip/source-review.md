# O3-B1 R1 correction: independent source review

## Source conclusion

The R1 mapping-limit correction passes source review. This conclusion does not imply complete hosted CI or integration approval.

The previous implementation could issue a POST with mapping output support of zero, reserve 4096 generated tokens, and settle 1415 generated tokens as SUCCEEDED. The supplied correction now checks the original mapping before selection and before each cognition boundary. All five meters are covered: calls, input tokens, generated tokens, micro-USD and milliseconds.

MappingLimits preserves the exact original mapping checks, including provider, adapter, selected model reference, dispatch ID, configuration digest, revision pin, uniqueness and current expiry. It validates complete integer meter shape and compares against unchanged per-call maxima. BaseProjection authenticates the original factual projection before demoting incompatible candidates; no factual PASS is manufactured and no provider allowance is raised. The original O1 selector retains deterministic selection and may select a supported alternative.

FreshProducer reconstructs the original-backed projection before publication and when resolving the current holder. AugurAdapter resolves the selected mapping again against the actual prepared maximum; the existing custody revalidation, dispatch-resource reconstruction and response-validation paths invoke that context. Missing, revoked or expired sources still refuse. The same KeySource and private delivery path are retained. Uncertainty remains unsettled when expiry occurs after claim admission.

The unchanged reviewer regression tests output-zero refusal through real signing/admission and Runtime. New tests cover each meter below its required bound, zero bounds, supported-alternative selection, equality at all five maxima with actual mocked cognition, and map expiry between credential consumption and callback. The original complete bridge and refusal tests remain byte-identical.

## Integrity

- Preparation commit: 02ce09621c63822eaff9ffd23151d5d3aed593a4.
- Correction entry: 18ff81299c42dc9fb60d49b419be8b7cfc38d1e3.
- Tested local correction: 17a23127fb349572cd4f8b357d679111ce312d7d.
- Final local commit: 9c1e953b9d580010ed4bbf684b7fc215de770f27.
- Final source tree: 7389ad3901e79ace26882e9c37e8eedbfc9f9155.
- Published review head: 1234f8459372f3fd9735a61299dcc887c3ad3c32.
- Verified 250 payload manifest entries, 57 canonical changed files and all 1852 tracked tested PHP byte streams against tested and final Git objects.
- Both preparation-to-final and correction-entry-to-final patches reconstruct the exact final tree.
- Supplied reviewer PHP files are byte-identical to the independent R1 packet.
- Protected-original comparisons verified by Git object identity for all 3359 preparation files and 3391 correction-entry files. Only declared seams and documentation changed; original tests, dependencies and full workflow remain unchanged.
- Inner ZIP SHA-256 verified. Independent static specification checks: 86 passed. Git diff check passed.

## Evidence distinction

The author supplied fresh local logs recording 877 selected tests and 8277 assertions passing. These were inspected, but local PHP is unavailable in the review workspace; independent PHP execution uses hosted CI. The separate diagnostic branch changes only the workflow over the exact corrected source and runs the unchanged reviewer test and mapping boundary/currentness tests. It is not an implementation or substitute full-CI gate.

Implementation PR: https://github.com/gatomontes/imperium-symfony/pull/794
Full corrected CI: https://github.com/gatomontes/imperium-symfony/actions/runs/34693266899
Diagnostic PR (do not merge): https://github.com/gatomontes/imperium-symfony/pull/796
Focused correction CI: https://github.com/gatomontes/imperium-symfony/actions/runs/34693350866

See final-ci-status.json and the captured logs for final hosted results. Main is not changed by review publication. All operational flags remain false; no real provider or installed-state operation is authorized.
