# Full-suite runtime investigation notes

These are static profiling leads, not measured attribution and not an authorization to weaken validation.

The original candidate full run 34688187703 started its full suite at 10:20:48 UTC and was cancelled around 10:50:46 on 2026-09-12, at the unchanged 30-minute job allowance. Its last complete PHPUnit progress row showed 244 / 3641 tests; later public bridge messages confirm W1, W2 and W3 validation completed by 10:36:03. That progress row is not a count of every test executed before cancellation.

The corrected packet records 8,305.485 seconds across its selected local final commands. The longest selections are the existing O3-B1 refusals (45:42.030), new mapping selection (26:34.263), and existing bridge (19:06.358). These Windows local durations are not predictions of hosted Linux runtime.

Profile these production paths on unchanged synthetic fixtures:

- FormationJournal::latest reads, decodes and hashes every retained generation each time read, inspect or changeAtHead resolves the current frame.
- AuthorityStore::state invokes complete LedgerState validation. V3 StateValidation invokes AugurMigration validation, which validates the preserved V2 prior state, then validates the current state and holder.
- CustodyCoordinator::check invokes prepareCurrent, then CommandLedger::operation invokes authority verification, which reconstructs the same Augur context. Context calls FreshProducer::current and BaseProjection::propose, including further complete-state validation and source verification.
- AuthorityStore::checkSource recursively resolves admitted source graphs, repeats retained-byte decoding and signature verification, and intentionally checks revocations and current time. Its existing depth, cycle and visit limits must remain enforced.

A correction must identify measured dominant costs. Do not skip checkpoint validation, truncate history, replace authentic fixture admission with injected state, remove tests, introduce process-global successful-authority caches, enlarge the full-suite allowance, or claim focused tests constitute full CI. Reuse of immutable computation must have a documented lifetime and exact identity, while all time, revocation, root, key generation and source-currentness decisions remain fresh at every boundary.
