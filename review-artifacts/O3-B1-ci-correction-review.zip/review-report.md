# O3-B1 correction review — R1 resolved; R2 blocks acceptance

## Verdict

R1 passes independent source review and hosted regression verification. O3-B1 is not accepted for integration: fresh full CI did not complete within the unchanged 30-minute job allowance. PR #794 remains draft and unmerged.

## R1 — resolved

The unchanged independent regression now records mapping_output_limit=0, post_count=0 and refusal=O2_BASE_NOT_ELIGIBLE, with no reservation or outcome. Hosted result: 1 test / 2 assertions in 47.501 seconds.

The correction boundary/currentness selection also passes: 16 tests / 130 assertions in 13:47.363. Together: 17 tests / 132 assertions. These verify all five mapping meters, supported alternatives, exact-boundary cognition and expiry before callback. PHP 8.4.25 / PHPUnit 13.3.0. Production PHP and tests exactly match the uploaded correction; only the separate diagnostic workflow differs.

Focused run: https://github.com/gatomontes/imperium-symfony/actions/runs/34693350866

## R2 — high priority: full-suite runtime prevents the required complete CI proof

Fresh corrected run: https://github.com/gatomontes/imperium-symfony/actions/runs/34693266899
Job: 103552234019. Full command: vendor/bin/phpunit tests. Workflow timeout-minutes: 30, unchanged.

The full command began at 12:17:38 UTC on 2026-09-12. GitHub cancelled it at 12:47:38; no complete suite result was emitted. The last complete progress row was 244 / 3658, followed by W1/W2/W3 validation markers ending at 12:32:34. The progress row is not an exact count of every test executed before cancellation. The log shows no assertion failure before cancellation, but that does not establish a full pass. The separate credential regression passed 1 test / 1 assertion.

Actual full-CI checkout: 6f183bf3c4f71bb97a1608321bbcde374cdd9e25. Its tree is 7389ad3901e79ace26882e9c37e8eedbfc9f9155, exactly matching uploaded final commit 9c1e953b9d580010ed4bbf684b7fc215de770f27 and published review head 1234f8459372f3fd9735a61299dcc887c3ad3c32. This is a fresh failure to finish on corrected source, not reuse of the original candidate's cancelled run.

The earlier full candidate also reached the same limit. The new focused mapping suite alone takes nearly fourteen hosted minutes, while the complete bridge emits roughly three minutes between each cognition marker. These observations warrant profiling; they do not identify one measured root cause. See performance-review-notes.md for concrete static leads in journal history, structural validation and repeated source/context reconstruction.

Required correction: profile and reduce the runtime cost of the real offline path sufficiently for the unchanged complete CI gate, preserving every original test and all currentness, custody, immutable-history and resource checks. Do not raise the timeout, narrow the full command, skip tests, seed fabricated successful state or replace live boundary validation with stale cached authority.

## Integrity and next action

The packet's 250 manifest entries, 57 canonical source files, 1852 tested PHP files, both patch reconstructions, unchanged reviewer additions, protected-original comparisons and inner ZIP checksum all verify. Independent static specification: 86 passed. Full details are in source-review.md and the JSON evidence.

Run correction-prompt.txt in the existing local O3-B1 implementation worktree. No pull is needed to apply this review; preserve untracked handoff files. Return provider-onboarding-o3-b1-ci-correction-all-deliverables.zip for independent review and fresh complete hosted CI. No merge, actual provider call, installed-state operation, O4 or O5 work is authorized.
