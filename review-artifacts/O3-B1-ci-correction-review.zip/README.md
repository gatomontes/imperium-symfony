# O3-B1 CI correction review

R1 is fixed and independently verified. R2 remains: full CI did not finish within its unchanged 30-minute allowance.

1. Extract this ZIP.
2. Open the existing O3-B1 implementation worktree in local Codex.
3. Start a chat, paste correction-prompt.txt in full, and attach this extracted review folder.
4. Return provider-onboarding-o3-b1-ci-correction-all-deliverables.zip here.

No pull or merge is needed for this handoff. The diagnostic workflow is not an implementation change and must not be merged.
