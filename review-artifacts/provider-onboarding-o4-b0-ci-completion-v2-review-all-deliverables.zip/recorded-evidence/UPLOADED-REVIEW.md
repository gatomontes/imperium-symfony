# Review: INCOMPLETE / HOLD

Two source corrections are retained after repeated real-workflow gains. Neither corrected full run completed within the unchanged allowance. The concrete unresolved condition is the complete gate timing out on the frozen corrected source; this is not proof that further correction is impossible.

## Source and behavior

Entry is `8fb6323e615432a949ce4bf599389d501650b2df`. Commit `aba70a009219494862695a37bd0fee7d1bbd0b97` reduces exact JSON indexing/comparison/key-encoding work, adds parse scopes inside existing custody owner callbacks, and reuses canonical encoding for five measured journal fields during one traversal. Commit `c2dc4cb647877e4057214355f6c4d33d9f365c5f` additionally reuses parsing of complete matching raw field fragments.

Native string indexing still checks complete original bytes. Encoding reuse requires complete strict values. Journal reuse is private to one traversal and bounded by five entries, 65536 nodes, 8 MiB each of raw string/key bytes, canonical bytes and native field-fragment bytes. Floats cannot enter this journal reuse. Parsing optimization falls back to the original native decoder above 16 MiB, on marker conflicts, beyond 64 matches or 65536 lexical structural tokens, or when depth cannot be proved safe. Parent depth is at most 128 and cached subtree depth at most 64, preventing hidden depth-512 errors even in overwritten duplicate members. Shortened-decode errors fall back to the original raw decoder. Exceptions clear retained representations.

Every journal file is freshly read; each complete frame digest is freshly computed. Existing digest, schema, generation, predecessor, filename, state and authority checks retain their sequence. Signature, currentness and permission results are not cached. Original tests, fixtures, configs, documentation inventories and dependency locks are unchanged. The production delta is four modified existing PHP files and eight additive PHP files, fully listed in the all-file comparison.

## Controlled result

The largest unchanged ordinary/custodied consumer passed with 45 assertions in each run:

| Source | Quiet serial elapsed seconds |
|---|---:|
| Entry | 455.997 |
| Canonical-field correction | 397.467, 395.807 |
| Retained parser correction | 344.679, 339.943 |

The retained parser measurements are approximately 24-25% below the quiet entry measurement. They are selected-workflow evidence, not a prediction of full-suite completion. Runtime, source-selection prelude, original test and JUnit setup were held constant; source hashes were unchanged. Promotion preserves the logical source, with documented newline normalization to exact Git bytes.

A further direct three-string reference encoder took 343.585 seconds and did not establish improvement over parser-only runs; it was rejected. Other rejected experiments and their raw results remain in the diagnostic package. Exploratory runs with preparation activity are not promoted to quiet controlled comparisons.

## Gate and limitations

The first corrected full gate at aba70 timed out after 1800.234 seconds. The latest at c2dc4cb6 timed out after 1800.219 seconds. Both used the unchanged complete command and allowance. Latest production diagnostic selections passed 47 tests and 6422 assertions, including currentness-after-consumption, foreign-instance refusal and the original reviewer probe. These are not substitutes for the failed complete gate.

The corrected largest-workflow profile still attributes substantial exclusive time outside checkpoints to CanonicalJson encoding (65.326s), journal decoding (45.553s), StrictJson canonical processing (38.151s), native signatures (25.470s) and strict parsing (22.236s). These instrumented costs identify investigation targets; inclusive values must not be added and instrumentation time is not directly comparable to the quiet runs.

The per-run reconstruction audit resolves all production and controlled performance manifests. Two exact file versions from the earlier 40-test pre-signed-zero-fix subtree diagnostic remain unavailable; their recorded hashes/logs, later fixed source and signed-zero reproducer are retained. This limits reconstruction of that intermediate diagnostic only. Do not claim every historical prototype version is fully reconstructed. The final rejected subtree and all retained production source are present.

Fresh independent hosted CI remains necessary before O4 acceptance. No hosted result was obtained or rechecked. The review's remote equivalent and draft PR 798 are historical supplied context, not a newly verified remote state. Do not merge while the complete gate is missing.
