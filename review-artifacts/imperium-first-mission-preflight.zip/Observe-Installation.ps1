param(
    [Parameter(Mandatory = $true)][string]$InstalledRoot,
    [string]$OutputParent = (Join-Path $env:USERPROFILE 'Downloads')
)
$ErrorActionPreference = 'Stop'
$rootItem = Get-Item -LiteralPath $InstalledRoot
if (-not $rootItem.PSIsContainer) { throw 'The designated installation must be a directory.' }
$root = $rootItem.FullName
$commands = @()
function Read-GitMetadata {
    param([string[]]$GitArguments)
    $result = @(& git --no-optional-locks -c core.fsmonitor=false -C $root @GitArguments 2>&1)
    $code = $LASTEXITCODE
    $script:commands += [ordered]@{ tool = 'git'; arguments = $GitArguments; exit = $code }
    if ($code -ne 0) { throw ('Git metadata observation failed for ' + ($GitArguments -join ' ')) }
    return ($result -join "`n")
}
$commit = Read-GitMetadata -GitArguments @('rev-parse', 'HEAD')
$tree = Read-GitMetadata -GitArguments @('rev-parse', 'HEAD^{tree}')
$top = Read-GitMetadata -GitArguments @('rev-parse', '--show-toplevel')
$resolvedTop = (Get-Item -LiteralPath $top).FullName
if ($resolvedTop.TrimEnd('\','/') -ne $root.TrimEnd('\','/')) { throw 'Use the confirmed installation repository root, not a subdirectory.' }
$drift = Read-GitMetadata -GitArguments @('status', '--porcelain', '--untracked-files=no')
$surfacePaths = @(
    'src/Command/SourceReviewCommand.php',
    'src/Imperium/Runtime/Mission/BoundedOperationalExecutionService.php',
    'src/Imperium/Runtime/Onboarding/Assignment/PersistentSettings.php',
    'docs/courtyard-fc-acceptance.md',
    'docs/provider-onboarding-implementation-roadmap.md'
)
$present = Read-GitMetadata -GitArguments (@('ls-tree', '-r', '--name-only', 'HEAD', '--') + $surfacePaths)
$php = Get-Command php -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
$phpObservation = $null
if ($null -ne $php) {
    $version = @(& $php.Source -n --version 2>&1)
    $phpCode = $LASTEXITCODE
    $phpObservation = [ordered]@{ executable = $php.Source; arguments = @('-n','--version'); exit = $phpCode; output = ($version -join "`n"); installed_application_booted = $false }
}
$observation = [ordered]@{
    schema = 'imperium.first-mission-metadata-observation/v1'
    observed_at_utc = [DateTime]::UtcNow.ToString('o')
    operator_designated_root = $root
    source_commit = $commit
    source_tree = $tree
    tracked_status = $drift
    committed_surface_paths = @($present -split "`n" | Where-Object { $_ })
    running_process_identity_verified = $false
    php = $phpObservation
    public_readiness_evidence = [ordered]@{ installation = $null; trust = $null; institutions = $null; appointments = $null; transport = $null }
    public_evidence_state = 'NOT_SUPPLIED_TO_THIS_OBSERVER'
    provider_calls = 0
    mission_executed = $false
    commands = $commands
}
$destination = Join-Path $OutputParent ('imperium-first-mission-preflight-' + [guid]::NewGuid())
$null = New-Item -ItemType Directory -Path $destination
$jsonPath = Join-Path $destination 'installation-observation.json'
[IO.File]::WriteAllText($jsonPath, ($observation | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
Write-Output ('Preflight observation: ' + $jsonPath)
Write-Output 'Metadata only. No application boot, provider call, or mission execution.'
