# First mission — local preflight required

The mission has not executed. The available session exposes repository tools, not a callable connection to the user's Windows installation. Genuine current installation/trust/appointments/custody/transport evidence is not available here. The existing public-readiness template has five null fields and is not evidence of either readiness or absence.

The scoped mission is a read-only review of the O5 CLI specification. MISSION.md records the target Courtyard-to-result route and its effect bounds. The public inputs are included for inspection; they are not an executable provider payload or authorization. Their manifest hashes preserve exact bytes. O5 specification source is preparation commit a1f227a6e0951b82c1e958b133bbcc94e4e1138a; the two canonical contracts are preserved from the reviewed O4 V2 source. Reconfirm them against the eventual accepted execution baseline before submission.

Immediate action: give LOCAL-PROMPT.md to the local agent. It performs one ten-minute installation preflight, with no PHP application boot, tests, profiling, CI, provider call, source deployment, enrollment or O4 restart. It stops with the earliest real blocker and a precise next action. The supplied PowerShell observer writes a new report under Downloads and reads Git metadata only, plus PHP's no-ini version when available.

Manual alternative, run with the actual operator-confirmed installation root:

```powershell
.\Observe-Installation.ps1 -InstalledRoot 'ACTUAL_INSTALLATION_ROOT'
```

The path above is a placeholder, not an instruction to use a historical installation or the current development worktree. The PowerShell script was source-reviewed but not executed in this environment; no Windows/runtime validation is claimed. Return installation-observation.json and the local agent's short PRECHECK-RESULT.md. Do not upload private keys, credentials or raw private state.

No provider price, installed identity, authority record or mission success has been invented. The existing direct source-review command uses a different entry route and has not been used as a substitute for the requested end-to-end proof.
