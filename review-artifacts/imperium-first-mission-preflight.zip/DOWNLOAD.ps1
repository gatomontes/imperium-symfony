$ErrorActionPreference = 'Stop'
git fetch origin refs/heads/codex/first-mission-preflight
if ($LASTEXITCODE -ne 0) { throw 'Fetch failed' }
$tempZip = Join-Path $env:TEMP ('first-mission-' + [guid]::NewGuid() + '.zip')
git archive --format=zip --output="$tempZip" FETCH_HEAD:review-artifacts imperium-first-mission-preflight.zip
if ($LASTEXITCODE -ne 0) { throw 'Archive failed' }
Expand-Archive -LiteralPath $tempZip -DestinationPath "$env:USERPROFILE\Downloads" -Force
Remove-Item -LiteralPath $tempZip
