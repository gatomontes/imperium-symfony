# O4-B0 preparation — all deliverables

O3-B1 is accepted, merged and closed in PR #794. O4 preparation is integrated in PR #797. This is a documentation preparation packet, not O4 implementation acceptance.

Run the commands in `start-o4-b0.ps1` from your existing repository. They fetch the pinned preparation and create an isolated worktree. Start a local Codex chat there and paste the full prompt printed by the last command. The full prompt is also in `canonical/docs/handoffs/provider-onboarding-o4-b0-local-prompt.txt`.

Implement the O4 contract: atomic whole-set Courtthane/Locksmith model settings, persistent resolution and explicit operator change/revalidation. Return the implementation packet for source review and fresh full hosted CI. O5 and live commissioning remain separate.

Contents: all 12 canonical preparation files; exact patch and incremental Git bundle (requires the baseline commit); source identities; static check output; unchanged PHP blob proof; bundle verification; local start script. `O4-B0-preparation-review.zip` is the inner review packet; verify its SHA-256 using the adjacent checksum file. `manifest.json` binds every payload file except itself. No outer checksum is supplied.

Validation: 86 static checks passed; all 1,853 PHP files match accepted O3 bytes. No local PHP execution is claimed. Inherited full O3 CI passed 3,664 tests / 57,357 assertions / four skips; automatically triggered documentation CI is separate and not reported as passed here.

The Git bundle preserves exact commit identity. To inspect it without changing worktree files, run `git bundle verify <path-to-bundle>` in a checkout containing baseline 61d3f555d4bc903437687d454f05f4484ff538c4. The patch is relative to that same baseline. No credentials, installed-state data or private runtime evidence are included.
