$ErrorActionPreference = "Stop"
# Run from the existing imperium-symfony repository. Choose fresh names if occupied.
git fetch origin refs/heads/codex/provider-onboarding-o4-b0-preparation
if ($LASTEXITCODE -ne 0) { throw "Fetch failed" }
$expected = "f544b696a0ebdf8c25a71f3a369e5a93738074e9"
$actual = (git rev-parse FETCH_HEAD).Trim()
if ($actual -ne $expected) { throw "Preparation branch moved; expected $expected, got $actual" }
git worktree add -b codex/provider-onboarding-o4-b0 ../imperium-onboarding-o4-b0 $expected
if ($LASTEXITCODE -ne 0) { throw "Worktree creation failed; choose a new name if it already exists" }
Set-Location ../imperium-onboarding-o4-b0
git status --short
git rev-parse HEAD
git rev-parse 'HEAD^{tree}'
Get-Content docs/handoffs/provider-onboarding-o4-b0-local-prompt.txt -Raw
